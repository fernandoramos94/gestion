// Horizontal bar JS
$('.sales-bar').horizBarChart({
	selector: '.bar',
	speed: 1000
});