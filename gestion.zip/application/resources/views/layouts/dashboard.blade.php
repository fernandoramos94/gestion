<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
	<head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Gestion y Administracion" />
		<meta name="keywords" content="Gestion y Admistracion" />
		<meta name="author" content="Fernando Ramos Timote" />
		<title>Gestión</title>
		
		<!-- Bootstrap CSS -->
		<link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" media="screen" />

		<!-- Main CSS -->
		<link href="{{ asset('css/main.css') }}" rel="stylesheet" media="screen" />

		<!-- Ion Icons -->
		<link href="{{ asset('fonts/icomoon/icomoon.css') }}" rel="stylesheet" />
		
		<!-- C3 CSS -->
		<link href="{{ asset('css/c3/c3.css') }}" rel="stylesheet" />

		<!-- NVD3 CSS -->
		<link href="{{ asset('css/nvd3/nv.d3.css') }}" rel="stylesheet" />

		<!-- Horizontal bar CSS -->
		<link href="{{ asset('css/horizontal-bar/chart.css') }}" rel="stylesheet" />

		<!-- Calendar Heatmap CSS -->
		<link href="{{ asset('css/heatmap/cal-heatmap.css') }}" rel="stylesheet" />

		<!-- Circliful CSS -->
		<link rel="stylesheet" href="{{ asset('css/circliful/circliful.css') }}" />

		<!-- OdoMeter CSS -->
		<link rel="stylesheet" href="{{ asset('css/odometer.css') }}" />

	</head>

	<body>

		<!-- Header starts -->
		<header>

			<!-- Logo starts -->
			<a href="index.html" class="logo">
				<img src="img/logo.png" alt="Arise Admin Dashboard Logo" />
			</a>
			<!-- Logo ends -->

			<!-- Header actions starts -->
			<ul id="header-actions" class="clearfix">
				<li class="list-box hidden-xs dropdown">
					<a id="drop2" href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-warning2"></i>
					</a>
					<span class="info-label blue-bg">5</span>
					<ul class="dropdown-menu imp-notify">
						<li class="dropdown-header">You have 3 notifications</li>
						<li>
							<div class="icon">
								<img src="img/thumbs/user10.png" alt="Arise Admin">
							</div>
							<div class="details">
								<strong class="text-danger">Rogie King</strong>
								<span>Firefox is a free, open-source web browser from Mozilla.</span>
							</div>
						</li>
						<li>
							<div class="icon">
								<img src="img/thumbs/user6.png" alt="Arise Admin">
							</div>
							<div class="details">
								<strong class="text-success">Dan Cederholm</strong>
								<span>IE is a free web browser from Microsoft.</span>
							</div>
						</li>
						<li>
							<div class="icon">
								<img src="img/thumbs/user1.png" alt="Arise Admin">
							</div>
							<div class="details">
								<strong class="text-info">Justin Mezzell</strong>
								<span>Safari is known for its sleek design and ease of use.</span>
							</div>
						</li>
						<li class="dropdown-footer">See all the notifications</li>
					</ul>
				</li>
				<li class="list-box hidden-xs dropdown">
					<a id="drop3" href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-archive2"></i>
					</a>
					<span class="info-label red-bg">3</span>
					<ul class="dropdown-menu progress-info">
						<li class="dropdown-header">You have 7 pending tasks</li>
						<li>
							<div class="progress-info">
								<strong class="text-danger">Critical</strong>
								<span>New Dashboard Design</span>
								<span class="pull-right text-danger">20%</span>
							</div>
							<div class="progress progress-md no-margin">
								<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%">
									<span class="sr-only">20% Complete (success)</span>
								</div>
							</div>
						</li>
						<li>
							<div class="progress-info">
								<strong class="text-info">Primary</strong>
								<span>UI Changes in V2</span>
								<span class="pull-right">90%</span>
							</div>
							<div class="progress progress-sm no-margin">
								<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%">
									<span class="sr-only">90% Complete</span>
								</div>
							</div>
						</li>
						<li>
							<div class="progress-info">
								<strong class="text-warning">Urgent</strong>
								<span>Bug Fix #123</span>
								<span class="pull-right">60%</span>
							</div>
							<div class="progress progress-xs no-margin">
								<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
									<span class="sr-only">60% Complete (warning)</span>
								</div>
							</div>
						</li>
						<li>
							<div class="progress-info">
								<span>Bug Fix #111</span>
								<span class="pull-right text-success">Complete</span>
							</div>
							<div class="progress progress-xs no-margin">
								<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
									<span class="sr-only">100% Complete (warning)</span>
								</div>
							</div>
						</li>
						<li class="dropdown-footer">See all the tasks</li>
					</ul>
				</li>
				<li class="list-box user-admin hidden-xs dropdown">
					<div class="admin-details">
						<div class="name">Sean</div>
						<div class="designation">System Admin</div>
					</div>
					<a id="drop4" href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-user"></i>
					</a>
					<ul class="dropdown-menu sm">
						<li class="dropdown-content">
							<a href="profile.html">Edit Profile</a>
							<a href="forgot-pwd.html">Change Password</a>
							<a href="styled-inputs.html">Settings</a>
                            <a href="{{ route('logout') }}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                Cerrar Sesión
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
						</li>
					</ul>
				</li>
				<li>
					<button type="button" id="toggleMenu" class="toggle-menu">
						<i class="collapse-menu-icon"></i>
					</button>
				</li>
			</ul>
			<!-- Header actions ends -->

			<div class="custom-search hidden-sm hidden-xs">
				<input type="text" class="search-query" placeholder="Search here ...">
				<i class="icon-search3"></i>
			</div>
		</header>
		<!-- Header ends -->

		<!-- Left sidebar start -->
		<div class="vertical-nav">

			<!-- Collapse menu starts -->
			<button class="collapse-menu">
				<i class="icon-menu2"></i>
			</button>
			<!-- Collapse menu ends -->

			<!-- Current user starts -->
			<div class="user-details clearfix">
				<a href="profile.html" class="user-img">
					<img src="img/thumbs/user1.png" alt="User Info">
					<span class="likes-info">9</span>
				</a>
				<h5 class="user-name">Sean</h5>
			</div>
			<!-- Current user ends -->

			<!-- Sidebar menu start -->
			<ul class="menu clearfix">
				<li class="active selected">
					<a href="#">
						<i class="icon-air-play"></i>
						<span class="menu-item">Dashboard</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="icon-lab3"></i>
						<span class="menu-item">Projects</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='tasks.html'>Tasks</a>
						</li>
						<li>
							<a href='cards.html'>Cards</a>
						</li>
						<li>
							<a href='users.html'>Users</a>
						</li>
						<li>
							<a href='project-list.html'>Project List</a>
						</li>
					</ul>
				</li>
				<li>
					<a href='calendar.html'>
						<i class="icon-calendar7"></i>
						<span class="menu-item">Calendar</span>
					</a>
				</li>
				<li>
					<a href='widgets.html'>
						<i class="icon-colours"></i>
						<span class="menu-item">Widgets</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="icon-head"></i>
						<span class="menu-item">Pages</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='profile.html'>User Profile</a>
						</li>
						<li>
							<a href='blog.html'>Blog</a>
						</li>
						<li>
							<a href='invoice.html'>Invoice</a>
						</li>
						<li>
							<a href='timeline.html'>Timeline</a>
						</li>
						<li>
							<a href="pricing.html">Pricing</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">
						<i class="icon-line-graph"></i>
						<span class="menu-item">Graphs</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='c3-graphs.html'>C3 Graphs</a>
						</li>
						<li>
							<a href='small-graphs.html'>Small Graphs</a>
						</li>
						<li>
							<a href='maps.html'>Vector Maps</a>
						</li>
						<li>
							<a href='flot.html'>Flot</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">
						<i class="icon-layout5"></i>
						<span class="menu-item">Forms</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='styled-inputs.html'>Styled Inputs</a>
						</li>
						<li>
							<a href='check-radio.html'>Check &amp; Radios</a>
						</li>
						<li>
							<a href='form-inputs.html'>Form Inputs</a>
						</li>
						<li>
							<a href='editor.html'>WYSIWYG Editor</a>
						</li>
					</ul>
				</li>
				<li>
					<a href='gallery.html'>
						<i class="icon-camera5"></i>
						<span class="menu-item">Gallery</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="icon-drop"></i>
						<span class="menu-item">UI Elements</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='components.html'>Components</a>
						</li>
						<li>
							<a href='progressbars.html'>Progress Bars</a>
						</li>
						<li>
							<a href='notifications.html'>Notifications</a>
						</li>
						<li>
							<a href='buttons.html'>Buttons</a>
						</li>
						<li>
							<a href='typography.html'>Typography</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">
						<i class="icon-layers4"></i>
						<span class="menu-item">Layouts</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='custom-drag.html'>Drag &amp; Drop Panels</a>
						</li>
						<li>
							<a href='custom-panels.html'>Custom Panels</a>
						</li>
						<li>
							<a href='sidebar-mini.html'>Sidebar Mini</a>
						</li>
						<li>
							<a href='default.html'>Basic Grid</a>
						</li>
						<li>
							<a href='custom-grid.html'>Custom Grid</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">
						<i class="icon-warning2"></i>
						<span class="menu-item">Error Pages</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='login.html'>Login</a>
						</li>
						<li>
							<a href='signup.html'>SignUp</a>
						</li>
						<li>
							<a href='forgot-pwd.html'>Forgot Password</a>
						</li>
						<li>
							<a href="maintenance.html">Maintenance</a>
						</li>
						<li>
							<a href='coming-soon.html'>Coming Soon</a>
						</li>
						<li>
							<a href='error.html'>Page not Found</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">
						<i class="icon-grid2"></i>
						<span class="menu-item">Tables</span>
						<span class="down-arrow"></span>
					</a>
					<ul>
						<li>
							<a href='tables.html'>Tables</a>
						</li>
						<li>
							<a href="data-tables.html">Data Tables</a>
						</li>
					</ul>
				</li>
				<li>
					<a href='icons.html'>
						<i class="icon-bolt"></i>
						<span class="menu-item">Icons</span>
					</a>
				</li>
			</ul>
			<!-- Sidebar menu snd -->
		</div>
		<!-- Left sidebar end -->

		<!-- Dashboard Wrapper Start -->
		<div class="dashboard-wrapper dashboard-wrapper-lg">

			<!-- Container fluid Starts -->
			<div class="container-fluid">

				<!-- Top Bar Starts -->
				<div class="top-bar clearfix">
					<div class="row gutter">
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<div class="page-title">
								<h3>Dashboard</h3>
								<p>Welcome to Arise Admin Dashboard</p>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<ul class="right-stats" id="mini-nav-right">
								<li>
									<a href="javascript:void(0)" class="btn btn-danger"><span>76</span>Sales</a>
								</li>
								<li>
									<a href="tasks.html" class="btn btn-info">
										<span>18</span>Tasks</a>
								</li>
								<li>
									<a href="javascript:void(0)" class="btn btn-success"><i class="icon-download6"></i> Export</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- Top Bar Ends -->

				<!-- Row starts -->
				<div class="row gutter">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel">
							<div class="website-performance">
								<div class="row gutter">
									<div class="col-lg-7 col-md-6 col-sm-6 col-xs-6">
										<div class="performance">
											<h5>Sales</h5>
											<div class="performance-graph">
												<div id="sales" class="chart-height5"></div>
											</div>
										</div>
									</div>
									<div class="col-lg-5 col-md-6 col-sm-6 col-xs-6">
										<div class="performance-stats">
											<h3 id="salesOdometer" class="odometer">0</h3>
											<p>21.2%<i class="icon-triangle-up up"></i></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel">
							<div class="website-performance">
								<div class="row gutter">
									<div class="col-lg-7 col-md-6 col-sm-6 col-xs-6">
										<div class="performance">
											<h5>Expenses</h5>
											<div class="performance-graph">
												<div id="expenses" class="chart-height5"></div>
											</div>
										</div>
									</div>
									<div class="col-lg-5 col-md-6 col-sm-6 col-xs-6">
										<div class="performance-stats">
											<h3 id="expensesOdometer" class="odometer">0</h3>
											<p>15.7%<i class="icon-triangle-down down"></i></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel">
							<div class="website-performance">
								<div class="row gutter">
									<div class="col-lg-7 col-md-6 col-sm-6 col-xs-6">
										<div class="performance">
											<h5>Profits</h5>
										</div>
										<div class="performance-graph">
											<div id="profits" class="chart-height5"></div>
										</div>
									</div>
									<div class="col-lg-5 col-md-6 col-sm-6 col-xs-6">
										<div class="performance-stats">
											<h3 id="profitsOdometer" class="odometer">0</h3>
											<p>19.3%<i class="icon-triangle-up up"></i></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Row ends -->

				<!-- Row starts -->
				<div class="row gutter">
					<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
						<div class="panel height2">
							<div class="panel-heading">
								<h4>Audience Overview</h4>
							</div>
							<div class="panel-body">
								<div id="stackedAreaChart" class="chart-height1">
									<svg></svg>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="row gutter">
							<div class="col-lg-6 col-md-3 col-sm-3 col-xs-6">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>Sessions</h4>
									</div>
									<div class="panel-body">
										<div class="sessions">
											<h2 class="text-danger">46K</h2>
											<div id="sessions" class="graph"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-3 col-sm-3 col-xs-6">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>Users</h4>
									</div>
									<div class="panel-body">
										<div class="sessions">
											<h2 class="text-warning">27K</h2>
											<div id="users" class="graph"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-3 col-sm-3 col-xs-6">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>Duration</h4>
									</div>
									<div class="panel-body">
										<div class="sessions">
											<h2 class="text-success">21.55</h2>
											<div id="duration" class="graph"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-3 col-sm-3 col-xs-6">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>Bounce Rate</h4>
									</div>
									<div class="panel-body">
										<div class="sessions">
											<h2 class="text-info">12.4%</h2>
											<div id="bouncerate" class="graph"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Row ends -->

				<!-- Row starts -->
				<div class="row gutter">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="row gutter">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>Money Spend</h4>
									</div>
									<div class="panel-body center-text">
										<span class="updating-chart">5,3,9,6,5,9,7,3,5,2,5,3,9,6,5,9,7,3,5,2</span>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>Online</h4>
									</div>
									<div class="panel-body">
										<div id="power-gauge"></div>
									</div>
								</div>
							</div>
						</div>
						<div class="row gutter">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>OS Stats</h4>
									</div>
									<div class="panel-body">
										<div class="row">
											<div class="col-md-4 col-sm-4 col-xs-4">
												<div class="os">
													<div id="mac"></div>
													<p class="no-margin">Mac</p>
												</div>
											</div>
											<div class="col-md-4 col-sm-4 col-xs-4">
												<div class="os">
													<div id="windows"></div>
													<p class="no-margin">Windows</p>
												</div>
											</div>
											<div class="col-md-4 col-sm-4 col-xs-4">
												<div class="os">
													<div id="linux"></div>
													<p class="no-margin">Linux</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="panel height2">
							<div class="panel-heading">
								<h4>Accounts</h4>
							</div>
							<div class="panel-body">
								<div class="chart-height3" id="bankAccounts">
									<svg></svg>
								</div>
								<ul class="bank-balance clearfix">
									<li>Credit: <span class="text-success"> $18,378</span></li>
									<li>Debit: <span class="text-danger"> $12,590</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<!-- Row ends -->

				<!-- Row starts -->
				<div class="row gutter">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel height2">
							<div class="panel-heading">
								<h4>Stocks</h4>
							</div>
							<div class="panel-body">
								<ul class="stocks">
									<li>
										<p class="clearfix">Apple Inc<span><i class="icon-triangle-up text-success"></i>465.45</span></p>
									</li>
									<li>
										<p class="clearfix">Google Inc<span><i class="icon-triangle-up text-success"></i>821.9</span></p>
									</li>
									<li>
										<p class="clearfix">Yahoo Inc<span><i class="icon-triangle-down text-danger"></i>31.88</span></p>
									</li>
									<li>
										<p class="clearfix">Facebook Inc<span><i class="icon-triangle-up text-success"></i>465.45</span></p>
									</li>
									<li>
										<p class="clearfix">Ebay Inc<span><i class="icon-triangle-down text-danger"></i>66.2</span></p>
									</li>
									<li>
										<p class="clearfix">Amazon Inc<span><i class="icon-triangle-up text-success"></i>278.73</span></p>
									</li>
									<li>
										<p class="clearfix">Microsoft<span><i class="icon-triangle-up text-success"></i>39.64</span></p>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel height2">
							<div class="panel-heading">
								<h4>App Downloads</h4>
							</div>
							<div class="panel-body">
								<ul class="app-downloads">
									<li>
										<p class="clearfix">
											<i class="icon-appleinc text-danger"></i>IOS<span>5769</span>
										</p>
										<div class="progress progress-md">
											<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100" style="width: 89%">
												<span class="sr-only">89% Complete (success)</span>
											</div>
										</div>
									</li>
									<li>
										<p class="clearfix">
											<i class="icon-android text-warning"></i>Android<span>2126</span>
										</p>
										<div class="progress progress-md">
											<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100" style="width: 55%">
												<span class="sr-only">55% Complete (success)</span>
											</div>
										</div>
									</li>
									<li>
										<p class="clearfix">
											<i class="icon-windows8 text-success"></i>Windows<span>1068</span>
										</p>
										<div class="progress progress-md">
											<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="29" aria-valuemin="0" aria-valuemax="100" style="width: 29%">
												<span class="sr-only">29% Complete (success)</span>
											</div>
										</div>
									</li>
									<li>
										<p class="clearfix">
											<i class="icon-download5 text-info"></i>Blackberry<span>285</span>
										</p>
										<div class="progress progress-md">
											<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 10%">
												<span class="sr-only">10% Complete (success)</span>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="row gutter">
							<div class="col-md-12">
								<div class="panel height2">
									<div class="panel-heading">
										<h4>Transactions</h4>
									</div>
									<div class="panel-body">
										<ul class="transactions">
											<li>
												<a href="javascript:void(0)">
													<span class="tra-icon">
														<i class="icon-shield3 text-danger"></i>
													</span>
													<span class="tra-type">Month Salary</span>
													<span class="tra-amount text-success">+7250</span>
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													<span class="tra-icon">
														<i class="icon-aircraft text-success"></i>
													</span>
													<span class="tra-type">Trip to Venice</span>
													<span class="tra-amount text-danger">-1100</span>
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													<span class="tra-icon">
														<i class="icon-shopping-cart text-info"></i>
													</span>
													<span class="tra-type">Shopping</span>
													<span class="tra-amount text-danger">-1890</span>
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													<span class="tra-icon">
														<i class="icon-bowl text-warning"></i>
													</span>
													<span class="tra-type">Lunch at work</span>
													<span class="tra-amount text-danger">-1250</span>
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													<span class="tra-icon">
														<i class="icon-pig text-danger"></i>
													</span>
													<span class="tra-type">Money left</span>
													<span class="tra-amount text-success">+9650</span>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Row ends -->

				<!-- Row starts -->
				<div class="row gutter">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="row gutter">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="panel height1">
									<div class="panel-heading">
										<h4>Subscribed Users</h4>
									</div>
									<div class="panel-body">
										<div class="chart-horiz clearfix">
											<ul class="sales-bar chart">
												<li class="current" title="Trails"><span class="bar" data-number="5679"></span><span class="number">5679</span></li>
												<li class="current" title="Subscriptions"><span class="bar" data-number="3458"></span><span class="number">3458</span></li>
												<li class="current" title="Expansions"><span class="bar" data-number="1934"></span><span class="number">1934</span></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="panel height1 center-text">
									<div id="chartExpenses"></div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="panel height1">
									<div class="panel-body">
										<div class="sessions">
											<h2 class="left">165<i class="icon-direction up"></i></h2>
											<div id="invoice" class="graph"></div>
										</div>
										<h5 class="info center-text">Invoices sent</h5>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Row ends -->

				<!-- Row starts -->
				<div class="row gutter">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel height1">
							<div class="panel-heading">
								<h4>Weekly Sales</h4>
							</div>
							<div class="panel-body">
								<div class="heatmap">
									<h2 class="text-danger">859</h2>
									<div id="cal-heatmap"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel height1">
							<div class="panel-heading">
								<h4>Tickets</h4>
							</div>
							<div class="panel-body">
								<ul class="tickets">
									<li>
										<a href="tasks.html">
											<h1 class="high no-of-tickets">21</h1>
											<p class="ticket-type">High</p>
										</a>
									</li>
									<li>
										<a href="tasks.html">
											<h1 class="no-of-tickets">6</h1>
											<p class="ticket-type">Low</p>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel height1">
							<div class="panel-heading">
								<h4>Mobile vs Desktop</h4>
							</div>
							<div class="panel-body">
								<div id="mobileDesktop" class="chart-height2"></div>
							</div>
						</div>
					</div>
				</div>
				<!-- Row ends -->

			</div>
			<!-- Container fluid ends -->
			
		</div>
		<!-- Dashboard Wrapper End -->

		<!-- Footer Start -->
		<footer>
			Todos los derechos reservado <span><a href="ohlimpiacanarias.com" target="_blank">ohlimpiacanarias.com</a> </span> - 2019
		</footer>
		<!-- Footer end -->

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="{{ asset('js/jquery.js') }}"></script>

		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="{{ asset('js/bootstrap.min.js') }}"></script>

		<!-- Sparkline Graphs -->
		<script src="{{ asset('js/sparkline/retina.js') }}"></script>
		<script src="{{ asset('js/sparkline/custom-sparkline.js') }}"></script>
		
		<!-- jquery ScrollUp JS -->
		<script src="{{ asset('js/scrollup/jquery.scrollUp.js') }}"></script>

		<!-- D3 JS -->
		<script src="{{ asset('js/d3/d3.v3.min.js') }}"></script>

		<!-- D3 Power Gauge -->
		<script src="{{ asset('js/d3/d3.powergauge.js') }}"></script>

		<!-- D3 Meter Gauge Chart -->
		<script src="{{ asset('js/d3/gauge.js') }}"></script>
		<script src="{{ asset('js/d3/gauge-custom.js') }}"></script>
		
		<!-- C3 Graphs -->
		<script src="{{ asset('js/c3/c3.min.js') }}"></script>
		<script src="{{ asset('js/c3/c3.custom.js') }}"></script>

		<!-- NVD3 JS -->
		<script src="{{ asset('js/nvd3/nv.d3.js') }}"></script>
		<script src="{{ asset('js/nvd3/nv.d3.custom.boxPlotChart.js') }}"></script>
		<script src="{{ asset('js/nvd3/nv.d3.custom.stackedAreaChart.js') }}"></script>

		<!-- Horizontal Bar JS -->
		<script src="{{ asset('js/horizontal-bar/horizBarChart.min.js') }}"></script>
		<script src="{{ asset('js/horizontal-bar/horizBarCustom.js') }}"></script>

		<!-- Gauge Meter JS -->
		<script src="{{ asset('js/gaugemeter/gaugeMeter-2.0.0.min.js') }}"></script>
		<script src="{{ asset('js/gaugemeter/gaugemeter.custom.js') }}"></script>

		<!-- Calendar Heatmap JS -->
		<script src="{{ asset('js/heatmap/cal-heatmap.min.js') }}"></script>
		<script src="{{ asset('js/heatmap/cal-heatmap.custom.js') }}"></script>

		<!-- Odometer JS -->
		<script src="{{ asset('js/odometer/odometer.min.js') }}"></script>
		<script src="{{ asset('js/odometer/custom-odometer.js') }}"></script>

		<!-- Peity JS -->
		<script src="{{ asset('js/peity/peity.min.js') }}"></script>
		<script src="{{ asset('js/peity/custom-peity.js') }}"></script>

		<!-- Circliful js -->
		<script src="{{ asset('js/circliful/circliful.min.js') }}"></script>
		<script src="{{ asset('js/circliful/circliful.custom.js') }}"></script>

		<!-- Custom JS -->
		<script src="{{ asset('js/custom.js') }}"></script>
	</body>
</html>