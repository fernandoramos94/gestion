window.onload=function(){
	setTimeout(function(){
		salesOdometer.innerHTML = 3569;
	}, 500);

	setTimeout(function(){
		expensesOdometer.innerHTML = 1265;
	}, 500);

	setTimeout(function(){
		profitsOdometer.innerHTML = 7640;
	}, 500);
}