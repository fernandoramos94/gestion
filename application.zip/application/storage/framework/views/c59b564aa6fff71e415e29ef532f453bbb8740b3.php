<?php $__env->startSection('content'); ?>
<div class="dashboard-wrapper dashboard-wrapper-lg">

    <!-- Container fluid Starts -->
    <div class="container-fluid">
        <div class="top-bar clearfix">
            <div class="row gutter">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="page-title">
                        <h3>LISTA DE EMPLEADOS</h3>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row starts -->
        <div class="row gutter">
        <!-- <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="users-wrapper red">
                    <div class="users-info clearfix">
                        <div class="users-avatar">
                            <img src="img/thumbs/user3.png" class="img-responsive" alt="Arise Admin">
                        </div>
                        <div class="users-detail">
                            <h5><?php echo e($employee->last_name); ?> <?php echo e($employee->first_name); ?></h5>
                            <p>UX Designer</p>
                        </div>
                    </div>
                    <ul class="users-footer clearfix">
                        <li>
                            <p class="light">Correo</p>
                            <p>Canada</p>
                        </li>
                        <li>
                            <p class="light">Telefono movil</p>
                            <p><?php echo e($employee->email); ?></p>
                        </li>
                        <li>
                            <a href="#" class="add-btn added">
                                <i class="icon-check"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel">
                    <div class="panel-body">
                        <table id="TablaEmpleado" class="table table-striped table-condensed table-bordered no-margin">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>DNI/NIE</th>
                                    <th>Email</th>
                                    <th>Telefono movil</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($employee->last_name); ?></td>
                                        <td><?php echo e($employee->first_name); ?></td>
                                        <td><?php echo e($employee->DNI_NIE); ?></td>
                                        <td><?php echo e($employee->email); ?></td>
                                        <td><?php echo e($employee->mobile_phone); ?></td>
                                        <td><?php echo e($employee->categorie); ?></td>    
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 
        </div>
        <!-- Row ends -->
    </div>
    <!-- Container fluid ends -->
    
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
// Basic DataTable
$(function(){
	$('#TablaEmpleado').DataTable({
		'iDisplayLength': 5,
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>