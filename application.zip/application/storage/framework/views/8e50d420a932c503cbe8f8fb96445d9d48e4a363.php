<?php $__env->startSection('content'); ?>
<div class="dashboard-wrapper dashboard-wrapper-lg">

    <!-- Container fluid Starts -->
    <div class="container-fluid">
        <div class="top-bar clearfix">
            <div class="row gutter">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="page-title">
                        <h3>LISTA DE DATOS BANCARIOS</h3>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row starts -->
        <div class="row gutter">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel">
                    <div class="panel-body">
                    <table id="TablaBankdata" class="table table-striped table-condensed table-bordered no-margin">
										<thead>
										  <tr>
									      <th>IBAN</th>
									      <th>Adjunto</th>
									      <th>Fecha de creación</th>
										  </tr>
										</thead>
										  
										<tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bankdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
												<td><?php echo e($bankdata->IBAN); ?></td>
												<td>
                                                    <a href="<?php echo e(asset('uploads')); ?>/<?php echo e($bankdata->url); ?>" download="<?php echo e($bankdata->url); ?>" class="btn btn-md btn-success"><span class="icon-download3"></span></a>
                                                </td>
                                                <td><?php echo e($bankdata->created_at); ?></td>  
										  </tr>
										  
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										  
										  
										
										</tbody>
									</table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row ends -->
    </div>
    <!-- Container fluid ends -->
    
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
// Basic DataTable
$(function(){
	$('#TablaBankdata').DataTable({
		'iDisplayLength': 5,
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>