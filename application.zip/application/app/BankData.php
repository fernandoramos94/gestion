<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankData extends Model
{
    protected $table = 'bank_data';
    protected $guarded = [];
}
